<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsuariosRol extends Model 
{

    protected $table = 'usuarios_rols';
    public $timestamps = true;

}