<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsuariosPlanes extends Model 
{

    protected $table = 'usuarios_plans';
    public $timestamps = true;

}